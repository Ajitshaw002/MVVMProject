package com.example.movieproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.movieproject.adapter.RecyclerMovieAdapter
import com.example.movieproject.model.MovieListExample
import com.example.movieproject.model.ResultsR
import com.example.movieproject.viewmodel.MainActivityViewModel
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    lateinit var mainActivityViewModel: MainActivityViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //get view model instance
        mainActivityViewModel = ViewModelProviders.of(this).get(MainActivityViewModel::class.java)
        //observe movie data
        observceMovieData()
    }


    private fun observceMovieData() {
        mainActivityViewModel.getAllMovies().observe(this, Observer {resultList->
            Log.e("aaaaa",resultList.get(0).title)
            Toast.makeText(this,resultList.get(0).title,Toast.LENGTH_SHORT).show()
            // setRecyclerView
            setRecyclerView(resultList)
        })
    }

    private fun setRecyclerView(resultList: List<ResultsR>?) {
        // Creates a vertical Layout Manager
        recyclerMovie.layoutManager = LinearLayoutManager(this)
        recyclerMovie.adapter = RecyclerMovieAdapter(this,resultList)

    }
}
