
package com.example.movieproject.model;

import java.util.List;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MovieListExample implements Parcelable
{

    @SerializedName("results")
    @Expose
    private List<ResultsR> resultsRS = null;
    @SerializedName("page")
    @Expose
    private Integer page;
    @SerializedName("total_results")
    @Expose
    private Integer totalResults;
    @SerializedName("dates")
    @Expose
    private Dates dates;
    @SerializedName("total_pages")
    @Expose
    private Integer totalPages;
    public final static Creator<MovieListExample> CREATOR = new Creator<MovieListExample>() {


        @SuppressWarnings({
            "unchecked"
        })
        public MovieListExample createFromParcel(Parcel in) {
            return new MovieListExample(in);
        }

        public MovieListExample[] newArray(int size) {
            return (new MovieListExample[size]);
        }

    }
    ;

    protected MovieListExample(Parcel in) {
        in.readList(this.resultsRS, (ResultsR.class.getClassLoader()));
        this.page = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.totalResults = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.dates = ((Dates) in.readValue((Dates.class.getClassLoader())));
        this.totalPages = ((Integer) in.readValue((Integer.class.getClassLoader())));
    }

    public MovieListExample() {
    }

    public List<ResultsR> getResultsRS() {
        return resultsRS;
    }

    public void setResultsRS(List<ResultsR> resultsRS) {
        this.resultsRS = resultsRS;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getTotalResults() {
        return totalResults;
    }

    public void setTotalResults(Integer totalResults) {
        this.totalResults = totalResults;
    }

    public Dates getDates() {
        return dates;
    }

    public void setDates(Dates dates) {
        this.dates = dates;
    }

    public Integer getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(Integer totalPages) {
        this.totalPages = totalPages;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeList(resultsRS);
        dest.writeValue(page);
        dest.writeValue(totalResults);
        dest.writeValue(dates);
        dest.writeValue(totalPages);
    }

    public int describeContents() {
        return  0;
    }

}
