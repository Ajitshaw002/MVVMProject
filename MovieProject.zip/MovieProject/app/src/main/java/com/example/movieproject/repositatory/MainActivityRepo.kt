package com.example.movieproject.repositatory

import android.app.Application
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.example.movieproject.R
import com.example.movieproject.RetrofitInstance
import com.example.movieproject.model.MovieListExample
import com.example.movieproject.model.ResultsR
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response





class MainActivityRepo(var application: Application){
    var arrayList:ArrayList<ResultsR> = ArrayList()
    var mutablLiveData:MutableLiveData<List<ResultsR>> = MutableLiveData()


    fun getMutableLiveData():MutableLiveData<List<ResultsR>>{
        val callService = RetrofitInstance.movieListService
        val call: Call<MovieListExample> = callService.getAllMovieData(application.getString(R.string.api_key))
        call.enqueue(object : Callback<MovieListExample> {
            override fun onFailure(call: Call<MovieListExample>, t: Throwable) {
                Log.d("WebAccess", "fail")

            }

            override fun onResponse(call: Call<MovieListExample>, response: Response<MovieListExample>) {
                Log.d("WebAccess", ""+response.body()!!.resultsRS.get(0).id)
                if (response.body()!= null) {
                    arrayList = (response.body()!!.resultsRS as? ArrayList<ResultsR>)!!
                    mutablLiveData.value = arrayList
                }
            }

        })
        return  mutablLiveData
    }


}