package com.example.movieproject.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.movieproject.R
import com.example.movieproject.model.ResultsR
import kotlinx.android.synthetic.main.recycler_item_movie_list.view.*

class RecyclerMovieAdapter(var ctx:Context,var resultSet:List<ResultsR>?) :
    RecyclerView.Adapter<RecyclerMovieAdapter.HolderItems>() {
    override fun getItemCount(): Int {
        return resultSet!!.size
    }

    override fun onBindViewHolder(holder: HolderItems, position: Int) {
        Glide.with(ctx)
            .load(resultSet!!.get(position).posterPath)
            //.placeholder(R.drawable.piwo_48)

            .into(holder.img_poster);
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HolderItems {
        return HolderItems(LayoutInflater.from(ctx).inflate(R.layout.recycler_item_movie_list, parent, false))
    }


    class HolderItems(view: View):RecyclerView.ViewHolder(view)
    {
        val img_poster = view.img_poster
    }
}