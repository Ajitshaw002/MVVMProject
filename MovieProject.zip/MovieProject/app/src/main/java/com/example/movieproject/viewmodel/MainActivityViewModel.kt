package com.example.movieproject.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.example.movieproject.model.ResultsR
import com.example.movieproject.repositatory.MainActivityRepo

class MainActivityViewModel(application: Application): AndroidViewModel(application) {

    lateinit var mainActivityRepo: MainActivityRepo
    init {
        mainActivityRepo = MainActivityRepo(application)
    }
    fun getAllMovies(): LiveData<List<ResultsR>>{

        return mainActivityRepo.getMutableLiveData()
    }
}